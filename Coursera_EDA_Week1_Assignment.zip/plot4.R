plot4 <- function(){
  if(!file.exists("household_power_consumption.txt"))
  {
    unzip("exdata_data_household_power_consumption.zip")
  }
  data_full <- read.csv("household_power_consumption.txt", header = TRUE, sep = ";",na.strings = "?", stringsAsFactors = FALSE)
  data_req <- subset(data_full, Date %in% c("1/2/2007", "2/2/2007"))
  data_req$Date <- as.Date(data_req$Date, "%d/%m/%Y")
  data_req$DateTime <- as.POSIXct(paste(data_req$Date, data_req$Time))
  
  png("plot4.png", width = 480, height = 480)
  par(mfrow = c(2,2))
  with(data_req, { 
    plot(DateTime, as.numeric(Global_active_power), col= "Black", type = "l", ylab = "Global Active Power", xlab= "")
    plot(DateTime, as.numeric(Voltage), col= "black", type ="l", xlab = "DateTime", ylab = "Voltage")
    {
      plot(DateTime, as.numeric(Sub_metering_1), col= "Black", type = "l", ylab = "Energy Sub metering", xlab= "")
      lines(data_req$DateTime, as.numeric(data_req$Sub_metering_2), col= "Red", type ="l")
      lines(data_req$DateTime, as.numeric(data_req$Sub_metering_3), col= "Blue", type = "l")
      legend("topright", lty = 1,  legend = c("Sub_metering_1", "Sub_metering_2", "Sub_metering_3"), 
             col = c("Black", "Red", "Blue"))
    }
    plot(DateTime, as.numeric(Global_reactive_power), col= "Black", type = "l", ylab = "Global Reactive Power", xlab= "DateTime")
  }
 )
  dev.off()
}