plot2 <- function(){
  if(!file.exists("household_power_consumption.txt"))
  {
    unzip("exdata_data_household_power_consumption.zip")
  }
  data_full <- read.csv("household_power_consumption.txt", header = TRUE, sep = ";",na.strings = "?", stringsAsFactors = FALSE)
  data_req <- subset(data_full, Date %in% c("1/2/2007", "2/2/2007"))
  data_req$Date <- as.Date(data_req$Date, "%d/%m/%Y")
  data_req$DateTime <- as.POSIXct(paste(data_req$Date, data_req$Time))
  
  png("plot2.png", width = 480, height = 480)
  plot(data_req$DateTime,as.numeric(data_req$Global_active_power), type = "l", ylab = "Global Active Power (kilowatts)", xlab = "")
  dev.off()
}