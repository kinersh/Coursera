plot1 <- function(){
  if(!file.exists("household_power_consumption.txt"))
  {
    unzip("exdata_data_household_power_consumption.zip")
  }
  data_full <- read.csv("household_power_consumption.txt", header = TRUE, sep = ";",na.strings = "?", stringsAsFactors = FALSE)
  data_req <- subset(data_full, Date %in% c("1/2/2007", "2/2/2007"))
  data_req$Date <- as.Date(data_req$Date, "%d/%m/%Y")
  data_req$DateTime <- as.POSIXct(paste(data_req$Date, data_req$Time))
  
  png("plot1.png", width = 480, height = 480)
  hist(as.numeric(data_req$Global_active_power), col= "Red", main = "Global Active Power", xlab = "Global Active Power (kilowatts)", ylab = "Frequency")
  dev.off()
}